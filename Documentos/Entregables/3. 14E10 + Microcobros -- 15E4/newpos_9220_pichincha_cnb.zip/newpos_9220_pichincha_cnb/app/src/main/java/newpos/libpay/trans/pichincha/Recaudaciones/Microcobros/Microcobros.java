package newpos.libpay.trans.pichincha.Recaudaciones.Microcobros;

import android.content.Context;

import newpos.libpay.trans.TransInputPara;
import newpos.libpay.trans.pichincha.Administrativas.InitTrans;
import newpos.libpay.trans.pichincha.Recaudaciones.Recaudaciones;
import newpos.libpay.utils.ISOUtil;

public class Microcobros extends Recaudaciones {


    String titulo = "Recaudación Microcobros";
    /**
     * 金融交易类构造
     *
     * @param ctx
     * @param transEname
     * @param tipoTrans
     * @param p
     */
    public Microcobros(Context ctx, String transEname, String tipoTrans, TransInputPara p) {
        super(ctx, transEname, tipoTrans, p);
    }

    public void pagoMicrocobros() {
        Amount = -1;

        String contrapartida = ingresoContrapartida(titulo,"TOKEN",6,1010101010,6);
        if (!contrapartida.equals("")){
            InitTrans.tkn03.setCodigoEmpresa(ISOUtil.padleft("01",10,'0').getBytes());
            InitTrans.tkn03.setContrapartida(ISOUtil.padright(contrapartida.toUpperCase(),34,' ').getBytes());

            if (enviarConsulta(proCodes.recauMicrocobrosConsulta)){
                mostrarRealizarEfectivacion(titulo,proCodes.recauMicrocobrosEfectivacion,setValores(),true,false);
            }
        }
    }

    private String[] setValores() {
        String[] valores = new String[5];
        valores[0] = ISOUtil.hex2AsciiStr(ISOUtil.byte2hex(InitTrans.tkn06.getNomEmpresa()));
        valores[1] = ISOUtil.hex2AsciiStr(ISOUtil.byte2hex(InitTrans.tkn06.getNomPersona()));
        valores[2] = ISOUtil.bcd2str(InitTrans.tkn06.getValor_adeudado(), 0, InitTrans.tkn06.getValor_adeudado().length);
        valores[3] = "¿Deseas pagar?";
        valores[4] = titulo;

        return valores;
    }
}

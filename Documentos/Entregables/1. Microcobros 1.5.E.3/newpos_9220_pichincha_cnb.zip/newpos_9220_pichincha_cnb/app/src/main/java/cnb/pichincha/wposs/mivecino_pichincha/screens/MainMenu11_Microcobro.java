package cnb.pichincha.wposs.mivecino_pichincha.screens;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import cn.desert.newpos.payui.UIUtils;
import cn.desert.newpos.payui.master.MasterControl;
import cnb.pichincha.wposs.mivecino_pichincha.R;
import newpos.libpay.device.printer.PrintRes;
import newpos.libpay.trans.pichincha.Administrativas.InitTrans;

public class MainMenu11_Microcobro extends AppCompatActivity implements View.OnClickListener {

    Button btnRecauMicrocobros;
    private String typeTrans;
    Button[] buttonsMenuRecau =  {btnRecauMicrocobros};
    String[] titulos = {"Recaudación Microcobros"};


    TextView tv1;
    CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_buttons_banner2);
        Botones();
        TheToolbar();
        Typeface tipoFuente1 = Typeface.createFromAsset(this.getAssets(), "font/PreloSlab-Book.otf");
        tv1 = findViewById(R.id.tv1);
        tv1.setText("Proveedores");
        tv1.setTypeface(tipoFuente1);
        temporizador();
    }

    /**
     *
     */
    private void Botones() {
        Typeface tipoFuente3 = Typeface.createFromAsset(this.getAssets(), "font/Prelo-Medium.otf");
        LinearLayout linearLayout = findViewById(R.id.linearBotones);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 120);
        lp.setMargins(0, 10, 0, 0);

        for (int i = 0; i < buttonsMenuRecau.length; i++) {
            buttonsMenuRecau[i] = new Button(this);
            buttonsMenuRecau[i].setBackgroundResource(R.drawable.pichi_btn_menu);
            buttonsMenuRecau[i].setLayoutParams(lp);
            buttonsMenuRecau[i].setText(titulos[i]);
            buttonsMenuRecau[i].setTextColor(Color.parseColor("#0F265C"));
            buttonsMenuRecau[i].setTypeface(tipoFuente3);
            buttonsMenuRecau[i].setTextSize(22);
            buttonsMenuRecau[i].setOnClickListener(this);
            buttonsMenuRecau[i].setAllCaps(false);
            linearLayout.addView(buttonsMenuRecau[i]);
        }

    }

    @Override
    public void onClick(View view) {

        if(view.equals(buttonsMenuRecau[0])) {
            countDownTimer.cancel();
            iniciarTrans(17, "Microcobros");
        }



    }

    /**
     *
     */
    public void TheToolbar(){
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    /**
     *
     */
    @Override
    public void onBackPressed() {
        countDownTimer.cancel();
        UIUtils.startView(MainMenu11_Microcobro.this, MainMenuPrincipal.class);
    }

    /**
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            countDownTimer.cancel();
            countDownTimer.start();
        }
        return super.onTouchEvent(event);
    }

    /**
     *
     * @param
     */
    public void temporizador(){
        countDownTimer = new CountDownTimer(InitTrans.time, 1000) {
            public void onTick(long millisUntilFinished) {
            }
            public void onFinish() {
                InitTrans.wrlg.wrDataTxt("Fin timer Recaudaciones, desde método temporizador, ingresa al menú principal.");
                countDownTimer.cancel();
                UIUtils.startView(MainMenu11_Microcobro.this, MainMenuPrincipal.class);
            }
        }.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        InitTrans.wrlg.wrDataTxt("Fin timer Recaudaciones, desde método onPause.");
        countDownTimer.cancel();
    }

    @Override
    protected void onResume(){
        super.onResume();
        try{
            MasterControl.masterCDT.cancel();
        }catch (Exception e){
            e.printStackTrace();
        }
        InitTrans.wrlg.wrDataTxt("Reinicio timer Recaudaciones, desde método onResume");
        countDownTimer.cancel();
        countDownTimer.start();
    }


    /**
     *
     * @param idTrans
     * @param tipoTrans
     */
    private void iniciarTrans(int idTrans, String tipoTrans){
        typeTrans = PrintRes.TRANSEN[idTrans];
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setClass(MainMenu11_Microcobro.this, MasterControl.class);
        intent.putExtra(MasterControl.TRANS_KEY, PrintRes.TRANSEN[idTrans]);
        intent.putExtra(MasterControl.tipoTrans, tipoTrans);
        startActivity(intent);
    }
}
